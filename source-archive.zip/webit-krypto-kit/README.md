webext-krypto-kit
=================

A port of the Krypto Kit plugin to run as pure JavaScript

Setup static file hosting for development purposes.  Browsers to not treat
local files the same as hosted files.

./configure.sh

# Running a local server
node src/webext/index.node.jc
